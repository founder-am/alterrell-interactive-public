import { useState, useCallback, useRef } from "react";

// ============================================================
// HELPERS
// ============================================================
const cmToIn = (cm) => cm / 2.54;
const lbsToKg = (lbs) => lbs / 2.20462;
const kgToLbs = (kg) => kg * 2.20462;

function getFrameSize(sex, heightIn, wristIn) {
  if (sex === "M") {
    if (wristIn < 6.5) return "Small";
    if (wristIn <= 7.5) return "Medium";
    return "Large";
  }
  if (heightIn < 62) {
    if (wristIn < 5.5) return "Small";
    if (wristIn <= 5.75) return "Medium";
    return "Large";
  }
  if (heightIn <= 65) {
    if (wristIn < 6.0) return "Small";
    if (wristIn <= 6.25) return "Medium";
    return "Large";
  }
  if (wristIn < 6.25) return "Small";
  if (wristIn <= 6.5) return "Medium";
  return "Large";
}

function getFrameDetail(sex, wristIn, ankleIn) {
  const base = sex === "M" ? 7.5 : 6.5;
  if (wristIn > base && ankleIn) {
    const thresh = sex === "M" ? 10.0 : 9.0;
    if (ankleIn > thresh) return "Very Large";
  }
  return null;
}

function calcBMI(wLbs, hIn) { return (wLbs / (hIn * hIn)) * 703; }

function getBMILabel(bmi) {
  if (bmi < 18.5) return { label: "Below reference range", color: "#3498db" };
  if (bmi < 25) return { label: "Within reference range", color: "#27ae60" };
  if (bmi < 30) return { label: "Above reference range", color: "#e67e22" };
  return { label: "Well above reference range", color: "#c0392b" };
}

function frameRange(sex, hIn, frame, ankleIn) {
  let base = sex === "M" ? 106 + 6 * (hIn - 60) : 100 + 5 * (hIn - 60);
  const adj = { Small: -0.1, Medium: 0, Large: 0.1, "Very Large": 0.18 }[frame] || 0;
  base *= 1 + adj;
  let bonus = 0;
  if (ankleIn) { const avg = sex === "M" ? 9.0 : 8.0; if (ankleIn > avg) bonus = (ankleIn - avg) * 5; }
  const ideal = base + bonus;
  return { floor: Math.round(ideal * 0.9), ceil: Math.round(ideal * 1.1), ideal: Math.round(ideal) };
}

function navyBF(sex, hIn, waistIn, neckIn, hipIn) {
  if (sex === "M") {
    const d = waistIn - neckIn; if (d <= 0) return null;
    return 86.01 * Math.log10(d * 2.54) - 70.041 * Math.log10(hIn * 2.54) + 36.76;
  }
  if (!hipIn) return null;
  const s = waistIn + hipIn - neckIn; if (s <= 0) return null;
  return 163.205 * Math.log10(s * 2.54) - 97.684 * Math.log10(hIn * 2.54) - 78.387;
}

function bfCat(bf, sex) {
  if (sex === "M") {
    if (bf < 14) return { label: "Athletic range", color: "#27ae60" };
    if (bf < 18) return { label: "Fitness range", color: "#2ecc71" };
    if (bf < 25) return { label: "Typical range", color: "#f39c12" };
    return { label: "Above typical range", color: "#e67e22" };
  }
  if (bf < 21) return { label: "Athletic range", color: "#27ae60" };
  if (bf < 25) return { label: "Fitness range", color: "#2ecc71" };
  if (bf < 32) return { label: "Typical range", color: "#f39c12" };
  return { label: "Above typical range", color: "#e67e22" };
}

function whrRisk(w, sex) {
  if (sex === "M") {
    if (w < 0.9) return { label: "Lower risk distribution", c: "#27ae60" };
    if (w < 1.0) return { label: "Moderate risk distribution", c: "#f39c12" };
    return { label: "Central distribution pattern", c: "#e67e22" };
  }
  if (w < 0.8) return { label: "Lower risk distribution", c: "#27ae60" };
  if (w < 0.85) return { label: "Moderate risk distribution", c: "#f39c12" };
  return { label: "Central distribution pattern", c: "#e67e22" };
}

// ============================================================
// LAB DEFINITIONS
// ============================================================
const LABS = {
  a1c: { label: "A1c", unit: "%", panel: "Requires specific order", segs: [
    { max: 5.7, label: "Within range", c: "#27ae60" }, { max: 6.4, label: "Approaching threshold", c: "#e67e22" }, { max: 14, label: "Above clinical threshold", c: "#c0392b" }
  ], lo: 4, hi: 10,
    q2: "My A1c has moved from [p] to [c] over [t]. What does this trajectory suggest, and what would you recommend?",
    q1: "My A1c is [c]. I don't have a prior reading. Can you help me understand what this means for someone with my frame and composition?" },
  glucose: { label: "Fasting Glucose", unit: "mg/dL", panel: "Included in CMP", segs: [
    { max: 100, label: "Within range", c: "#27ae60" }, { max: 125, label: "Approaching threshold", c: "#e67e22" }, { max: 300, label: "Above clinical threshold", c: "#c0392b" }
  ], lo: 60, hi: 200,
    q2: "My fasting glucose went from [p] to [c] over [t]. Is this trending in a direction we should address?",
    q1: "My fasting glucose is [c]. What would you want to see at my next test?" },
  triglycerides: { label: "Triglycerides", unit: "mg/dL", panel: "Included in Lipid Panel", segs: [
    { max: 150, label: "Within range", c: "#27ae60" }, { max: 199, label: "Approaching threshold", c: "#f39c12" }, { max: 500, label: "Above threshold", c: "#e67e22" }
  ], lo: 30, hi: 350,
    q2: "My triglycerides moved from [p] to [c] over [t]. Should we calculate my TG/HDL ratio?",
    q1: "My triglycerides are [c]. Can we also look at my TG/HDL ratio for insulin resistance markers?" },
  hdl: { label: "HDL Cholesterol", unit: "mg/dL", panel: "Included in Lipid Panel", inv: true, segs: [
    { max: 39, label: "Below target", c: "#e67e22" }, { max: 59, label: "Approaching target", c: "#f39c12" }, { max: 200, label: "Protective range", c: "#27ae60" }
  ], lo: 20, hi: 100,
    q2: "My HDL moved from [p] to [c] over [t]. What raises HDL most effectively for someone my size?",
    q1: "My HDL is [c]. What should I be doing to raise this?" },
  ldl: { label: "LDL Cholesterol", unit: "mg/dL", panel: "Included in Lipid Panel", segs: [
    { max: 100, label: "Within range", c: "#27ae60" }, { max: 129, label: "Near threshold", c: "#2ecc71" }, { max: 159, label: "Approaching threshold", c: "#f39c12" }, { max: 300, label: "Above threshold", c: "#e67e22" }
  ], lo: 40, hi: 220,
    q2: "My LDL moved from [p] to [c] over [t]. Should we discuss medication or lifestyle changes first?",
    q1: "My LDL is [c]. How does this look in context with my other lipid numbers?" },
  alt: { label: "ALT (Liver Enzyme)", unit: "IU/L", panel: "Included in CMP", segs: [
    { max: 40, label: "Within range", c: "#27ae60" }, { max: 80, label: "Above range", c: "#e67e22" }, { max: 200, label: "Well above range", c: "#c0392b" }
  ], lo: 5, hi: 120,
    q2: "My ALT moved from [p] to [c] over [t]. Could this be related to fatty liver or something else?",
    q1: "My ALT is [c]. Should we investigate what might be causing this?" },
  egfr: { label: "eGFR (Kidney)", unit: "mL/min", panel: "Included in CMP", inv: true, segs: [
    { max: 59, label: "Below threshold — discuss with provider", c: "#c0392b" }, { max: 89, label: "Approaching threshold", c: "#f39c12" }, { max: 200, label: "Within range", c: "#27ae60" }
  ], lo: 30, hi: 130,
    q2: "My eGFR moved from [p] to [c] over [t]. What's the rate of decline, and should we adjust anything?",
    q1: "My eGFR is [c]. Should we be monitoring this closely?" },
  vitd: { label: "Vitamin D", unit: "ng/mL", panel: "Requires specific order — ask for it", inv: true, segs: [
    { max: 20, label: "Below range", c: "#c0392b" }, { max: 29, label: "Below target", c: "#f39c12" }, { max: 100, label: "Within range", c: "#27ae60" }
  ], lo: 5, hi: 80,
    q2: "My Vitamin D moved from [p] to [c] over [t]. Should I adjust my supplement dose?",
    q1: "My Vitamin D is [c]. What dose would you recommend for someone my size?" },
};

function labStatus(key, val) {
  for (const s of LABS[key].segs) { if (val <= s.max) return s; }
  return LABS[key].segs[LABS[key].segs.length - 1];
}

function labTrend(key, cur, pri) {
  if (!pri) return null;
  const d = cur - pri, pct = Math.abs(d / pri) * 100;
  if (pct < 3) return { label: "Stable", c: "#7f8c8d", arrow: "→" };
  const better = LABS[key].inv ? d > 0 : d < 0;
  return better
    ? { label: "Moving in the right direction", c: "#27ae60", arrow: LABS[key].inv ? "↑" : "↓" }
    : { label: "Moving in a direction to watch", c: "#e67e22", arrow: LABS[key].inv ? "↓" : "↑" };
}

// ============================================================
// STYLES
// ============================================================
const iS = { width: "100%", padding: "10px 12px", border: "1px solid #ddd", borderRadius: "6px", fontSize: "15px", fontFamily: "inherit", background: "#fff", boxSizing: "border-box" };
const lS = { display: "block", fontSize: "13px", fontWeight: 500, color: "#555", marginBottom: "4px" };
const sH = { fontSize: "22px", fontWeight: 700, color: "#1a2535", margin: "0 0 4px" };
const crd = { background: "#fff", border: "1px solid #e8e8e8", borderRadius: "10px", padding: "20px", marginBottom: "16px" };
const rw = { display: "flex", gap: "12px", flexWrap: "wrap" };

// ============================================================
// SUB-COMPONENTS
// ============================================================
function NI({ label, value, onChange, placeholder, hint, step, sx }) {
  return (
    <div style={{ flex: 1, minWidth: "130px", ...sx }}>
      <label style={lS}>{label}</label>
      <input type="number" step={step || "any"} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} style={iS} />
      {hint && <div style={{ fontSize: "11px", color: "#aaa", marginTop: "2px" }}>{hint}</div>}
    </div>
  );
}

function Sel({ label, value, onChange, options, note }) {
  return (
    <div style={{ flex: 1, minWidth: "130px" }}>
      <label style={lS}>{label}</label>
      <select value={value} onChange={e => onChange(e.target.value)} style={{ ...iS, cursor: "pointer" }}>
        {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
      {note && <div style={{ fontSize: "11px", color: "#aaa", marginTop: "3px", lineHeight: 1.4 }}>{note}</div>}
    </div>
  );
}

function Badge({ label, color }) {
  return <span style={{ display: "inline-block", padding: "3px 9px", borderRadius: "12px", fontSize: "11px", fontWeight: 600, background: color + "18", color, border: `1px solid ${color}40`, whiteSpace: "nowrap" }}>{label}</span>;
}

function RangeBar({ value, segs, lo, hi }) {
  if (!value) return null;
  const pct = Math.max(0, Math.min(100, ((value - lo) / (hi - lo)) * 100));
  const range = hi - lo;
  const stops = [];
  let prev = 0;
  for (const s of segs) {
    const p = Math.min(100, Math.max(0, ((Math.min(s.max, hi) - lo) / range) * 100));
    stops.push(`${s.c}30 ${prev}%, ${s.c}30 ${p}%`);
    prev = p;
  }
  return (
    <div style={{ position: "relative", height: "16px", borderRadius: "8px", background: `linear-gradient(to right, ${stops.join(", ")})`, marginTop: "6px", border: "1px solid #e8e8e8" }}>
      <div style={{ position: "absolute", left: `calc(${pct}% - 5px)`, top: "-2px", width: "10px", height: "20px", borderRadius: "5px", background: "#1a2535", border: "2px solid #fff", boxShadow: "0 1px 4px rgba(0,0,0,0.3)", transition: "left 0.3s" }} />
    </div>
  );
}

function RB({ bc, title, value, sub }) {
  return (
    <div style={{ ...crd, borderTop: `3px solid ${bc || "#ddd"}`, flex: 1, minWidth: "200px", marginBottom: "10px" }}>
      {title && <div style={{ fontSize: "12px", color: "#888", fontWeight: 500, marginBottom: "3px" }}>{title}</div>}
      {value && <div style={{ fontSize: "26px", fontWeight: 700, color: bc || "#1a2535", lineHeight: 1.1 }}>{value}</div>}
      {sub && <div style={{ fontSize: "13px", color: "#666", marginTop: "6px", lineHeight: 1.5 }}>{sub}</div>}
    </div>
  );
}

function MG({ label, text }) {
  return (
    <div style={{ fontSize: "12px", color: "#777", background: "#f8f8f8", padding: "8px 10px", borderRadius: "6px", marginTop: "4px", lineHeight: 1.5 }}>
      <strong>How to measure {label}:</strong> {text}
    </div>
  );
}

// ============================================================
// MAIN APP
// ============================================================
export default function App() {
  const [units, setUnits] = useState("imperial");
  const [sex, setSex] = useState("M");
  const [hFt, setHFt] = useState("");
  const [hIn, setHIn] = useState("");
  const [hCm, setHCm] = useState("");
  const [wt, setWt] = useState("");
  const [wrist, setWrist] = useState("");
  const [ankle, setAnkle] = useState("");
  const [waist, setWaist] = useState("");
  const [hip, setHip] = useState("");
  const [neck, setNeck] = useState("");
  const [labs, setL] = useState({});
  const [prior, setP] = useState({});
  const [tf, setTf] = useState("unknown");
  const [guides, setGuides] = useState(false);
  const [panelInfo, setPanelInfo] = useState(false);
  const reportRef = useRef(null);

  const met = units === "metric";
  const du = met ? "cm" : "in";
  const wu = met ? "kg" : "lbs";
  const toI = v => v ? (met ? cmToIn(parseFloat(v)) : parseFloat(v)) : null;
  const toL = v => v ? (met ? kgToLbs(parseFloat(v)) : parseFloat(v)) : null;
  const showWt = (lbs) => met ? Math.round(lbsToKg(lbs)) + " kg" : lbs + " lbs";

  const tHIn = met ? (hCm ? cmToIn(parseFloat(hCm)) : null) : (hFt && hIn !== "" ? parseInt(hFt) * 12 + parseInt(hIn || 0) : null);
  const wLbs = toL(wt);
  const wI = toI(wrist), aI = toI(ankle), waI = toI(waist), nI = toI(neck), hpI = toI(hip);

  const canF = tHIn && wLbs && wI;
  const canB = tHIn && waI && nI;
  const hasL = Object.values(labs).some(v => v);

  const fs = canF ? getFrameSize(sex, tHIn, wI) : null;
  const fd = canF && aI ? getFrameDetail(sex, wI, aI) : null;
  const df = fd || fs;
  const bmi = canF ? calcBMI(wLbs, tHIn) : null;
  const bmiC = bmi ? getBMILabel(bmi) : null;
  const wr = canF ? frameRange(sex, tHIn, df, aI) : null;
  const bmiR = tHIn ? { lo: Math.round(18.5 * tHIn * tHIn / 703), hi: Math.round(24.9 * tHIn * tHIn / 703) } : null;
  const wrongBy = wr && bmiR ? Math.max(0, wr.floor - bmiR.hi) : null;

  const bf = canB ? navyBF(sex, tHIn, waI, nI, hpI) : null;
  const bfc = bf ? bfCat(bf, sex) : null;
  const lean = bf && wLbs ? wLbs * (1 - bf / 100) : null;
  const whr = waI && hpI ? waI / hpI : null;
  const whrS = whr ? whrRisk(whr, sex) : null;
  const tgH = labs.triglycerides && labs.hdl ? parseFloat(labs.triglycerides) / parseFloat(labs.hdl) : null;

  const tL = { "3mo": "about 3 months", "6mo": "about 6 months", "1yr": "about a year", "2yr": "about 2 years", unknown: "some time" }[tf];

  // Doctor questions
  const qs = [];
  if (wrongBy && wrongBy > 0) qs.push(`My skeletal frame is classified as "${df}" based on wrist (${wrist}${du}) and ankle (${ankle || "not measured"}${ankle ? du : ""}) circumference. Standard BMI charts suggest my upper healthy weight is ${showWt(bmiR.hi)}, but frame-adjusted analysis puts my healthy range at ${showWt(wr.floor)}–${showWt(wr.ceil)}. Can we use this adjusted range for my care plan?`);
  if (bf && bf > (sex === "M" ? 25 : 32)) qs.push(`My estimated body fat is ${bf.toFixed(1)}% (Navy circumference method, ±3.5%). Rather than focusing on scale weight alone, can we track body fat percentage and waist circumference as progress metrics?`);
  if (whr && whrS && whrS.c !== "#27ae60") qs.push(`My waist-to-hip ratio is ${whr.toFixed(2)}, which suggests a central fat distribution pattern. What specific interventions target visceral fat most effectively for someone at my weight?`);

  Object.keys(LABS).forEach(k => {
    if (!labs[k]) return;
    const v = parseFloat(labs[k]);
    const st = labStatus(k, v);
    if (st.c === "#27ae60") return;
    const pv = prior[k] ? parseFloat(prior[k]) : null;
    const tmpl = pv ? LABS[k].q2 : LABS[k].q1;
    qs.push(tmpl.replace("[c]", labs[k] + " " + LABS[k].unit).replace("[p]", pv ? prior[k] + " " + LABS[k].unit : "").replace("[t]", tL));
  });
  if (tgH && tgH > 2) qs.push(`My triglycerides-to-HDL ratio is ${tgH.toFixed(1)} (${labs.triglycerides} ÷ ${labs.hdl}). I've read that ratios above 2.0 may be associated with insulin resistance. Should we investigate further?`);

  const qText = qs.map((q, i) => `${i + 1}. ${q}`).join("\n\n");
  const hdr = "QUESTIONS FOR MY PROVIDER\nFrame-Adjusted Health Report\n" + new Date().toLocaleDateString() + "\n\n";

  const copy = useCallback(() => { navigator.clipboard.writeText(hdr + qText).then(() => alert("Copied! Paste into Notes, a text, or email.")); }, [qText, hdr]);
  const email = useCallback(() => { window.open(`mailto:?subject=${encodeURIComponent("Questions for my next appointment")}&body=${encodeURIComponent("Questions for my visit:\n\n" + qText + "\n\n(From Frame-Adjusted Health Report)")}`); }, [qText]);
  const text = useCallback(() => { window.open(`sms:?body=${encodeURIComponent("Doctor questions:\n\n" + qText)}`); }, [qText]);

  return (
    <div style={{ maxWidth: "760px", margin: "0 auto", padding: "20px 16px", fontFamily: '-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif', color: "#1a2535", background: "#fafafa", minHeight: "100vh" }}>

      {/* HEADER */}
      <div style={{ marginBottom: "24px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: "10px" }}>
          <h1 style={{ fontSize: "26px", fontWeight: 700, margin: 0 }}>Frame-Adjusted Health Report</h1>
          <div style={{ display: "flex", gap: "3px", background: "#eee", borderRadius: "8px", padding: "3px" }}>
            {[["imperial", "Imperial"], ["metric", "Metric"]].map(([v, l]) => (
              <button key={v} onClick={() => setUnits(v)} style={{ padding: "6px 14px", border: "none", borderRadius: "6px", fontSize: "13px", fontWeight: 600, cursor: "pointer", background: units === v ? "#fff" : "transparent", color: units === v ? "#1a2535" : "#888", boxShadow: units === v ? "0 1px 3px rgba(0,0,0,0.1)" : "none" }}>{l}</button>
            ))}
          </div>
        </div>
        <p style={{ fontSize: "14px", color: "#666", margin: "8px 0 0", lineHeight: 1.5 }}>
          BMI was designed for populations, not people. This tool uses your skeletal frame, body composition, and lab trends to generate specific questions for your healthcare provider. <strong>Nothing leaves your device.</strong>
        </p>
      </div>

      {/* SECTION 1: FRAME */}
      <div style={crd}>
        <h2 style={sH}>1. Body Frame Assessment</h2>
        <p style={{ fontSize: "13px", color: "#888", margin: "0 0 12px" }}>Your wrist and ankle have minimal soft tissue — they reveal your skeletal structure and determine whether standard weight charts apply to you.</p>

        <div style={rw}>
          <Sel label="Sex assigned at birth" value={sex} onChange={setSex}
            options={[{ value: "M", label: "Male" }, { value: "F", label: "Female" }]}
            note="We ask because skeletal frame reference ranges were developed along these lines. This is about bone structure, not identity." />
        </div>

        <div style={{ ...rw, marginTop: "10px" }}>
          {met
            ? <NI label="Height (cm)" value={hCm} onChange={setHCm} placeholder="175" />
            : <><NI label="Height (ft)" value={hFt} onChange={setHFt} placeholder="5" /><NI label="Height (in)" value={hIn} onChange={setHIn} placeholder="9" /></>
          }
          <NI label={`Weight (${wu})`} value={wt} onChange={setWt} placeholder={met ? "128" : "280"} />
        </div>

        <div style={{ ...rw, marginTop: "10px" }}>
          <NI label={`Wrist circumference (${du})`} value={wrist} onChange={setWrist} placeholder={met ? "19" : "7.5"} step="0.125" />
          <NI label={`Ankle circumference (${du})`} value={ankle} onChange={setAnkle} placeholder={met ? "25" : "10"} step="0.125" hint="Optional but recommended" />
        </div>

        <button onClick={() => setGuides(!guides)} style={{ background: "none", border: "none", color: "#0a7c72", fontSize: "13px", fontWeight: 600, cursor: "pointer", padding: "8px 0", marginTop: "4px" }}>{guides ? "▾ Hide" : "▸ How to"} measure</button>
        {guides && (
          <div style={{ display: "flex", flexDirection: "column", gap: "5px", marginTop: "2px" }}>
            <MG label="your wrist" text="Wrap a flexible tape around your wrist just above the bony bump on the outer side (where you'd wear a watch). Pull snug but not tight." />
            <MG label="your ankle" text="Wrap the tape around the narrowest part of your ankle, just above the ankle bones. Stand with weight on both feet." />
          </div>
        )}

        {canF && (
          <div style={{ marginTop: "16px", padding: "16px", background: "#f0faf8", borderRadius: "8px", border: "1px solid #d0e8e4" }}>
            <div style={rw}>
              <RB bc="#0a7c72" title="Your frame" value={df}
                sub={df === "Very Large" ? "Your skeletal structure is at the statistical extreme. Standard weight charts were not designed for this frame — they underestimate your healthy range significantly."
                  : df === "Large" ? "Your bone structure is larger than average. Standard weight tables underestimate your healthy range."
                  : "Standard weight tables are reasonably calibrated for your frame."} />
              <RB bc="#2980b9" title="Frame-adjusted healthy range" value={`${showWt(wr.floor)}–${showWt(wr.ceil)}`}
                sub={wrongBy > 0 ? `BMI says your ceiling is ${showWt(bmiR.hi)}. Your frame says ${showWt(wr.floor)} is the floor. BMI is off by at least ${showWt(wrongBy)} for your body.` : "Adjusted for your skeletal structure."} />
              <RB bc={bmiC.color} title="BMI (for context)" value={bmi.toFixed(1)}
                sub={`${bmiC.label} — but BMI doesn't account for frame size, muscle mass, or where you carry weight.`} />
            </div>
          </div>
        )}
      </div>

      {/* SECTION 2: BODY COMP */}
      <div style={crd}>
        <h2 style={sH}>2. Body Composition Estimate</h2>
        <p style={{ fontSize: "13px", color: "#888", margin: "0 0 12px" }}>The U.S. Navy circumference method estimates body fat from tape measurements. Accuracy is ±3.5% compared to a DEXA scan — good enough to track trends over time.</p>

        <div style={rw}>
          <NI label={`Waist at ${sex === "M" ? "navel" : "narrowest point"} (${du})`} value={waist} onChange={setWaist} placeholder={met ? "118" : "47"} />
          <NI label={`Neck at narrowest point below jaw (${du})`} value={neck} onChange={setNeck} placeholder={met ? "44" : "17"} />
          <NI label={`Hips at widest point (${du})`} value={hip} onChange={setHip} placeholder={met ? "131" : "52"} hint={sex === "M" ? "Optional — needed for waist-to-hip ratio" : "Required"} />
        </div>

        <button onClick={() => setGuides(!guides)} style={{ background: "none", border: "none", color: "#0a7c72", fontSize: "13px", fontWeight: 600, cursor: "pointer", padding: "8px 0" }}>{guides ? "▾ Hide" : "▸ How to"} measure</button>
        {guides && (
          <div style={{ display: "flex", flexDirection: "column", gap: "5px", marginTop: "2px" }}>
            <MG label="your waist" text={sex === "M" ? "Measure horizontally at navel level. Stand relaxed — don't suck in. Keep the tape level." : "Measure at the narrowest part of your torso, between your lowest rib and hip bone. Stand relaxed."} />
            <MG label="your neck" text="Measure at the narrowest point of your neck, just below your jawline. Keep the tape level. Look straight ahead." />
            <MG label="your hips" text="Stand with feet together. Measure at the widest point of your buttocks, keeping the tape level." />
          </div>
        )}

        {bf !== null && bf > 0 && (
          <div style={{ marginTop: "16px", padding: "16px", background: "#f5f3ff", borderRadius: "8px", border: "1px solid #e0daf5" }}>
            <div style={rw}>
              <RB bc={bfc.color} title="Estimated body fat" value={`${bf.toFixed(1)}% (±3.5%)`} sub={`${bfc.label}. A DEXA scan is the gold standard if you want more precision.`} />
              <RB bc="#1a5276" title="Lean mass (estimated)" value={showWt(Math.round(lean))} sub="Everything that isn't fat: bones, muscle, organs, water. This is the number to protect during weight loss." />
              {whr && <RB bc={whrS.c} title="Waist-to-hip ratio" value={whr.toFixed(2)} sub={`${whrS.label}. Where fat is distributed is often more important than how much.`} />}
            </div>
            {lean && (
              <div style={{ marginTop: "10px", padding: "12px", background: "#fff", borderRadius: "6px", fontSize: "14px", color: "#444", lineHeight: 1.6 }}>
                <strong>What this means for goals:</strong> Your lean mass is ~{showWt(Math.round(lean))}.
                At a target body fat of {sex === "M" ? "20" : "28"}%, your composition-based goal weight would be around <strong>{showWt(Math.round(lean / (1 - (sex === "M" ? 0.2 : 0.28))))}</strong>.
                Going much below {showWt(Math.round(lean / (1 - (sex === "M" ? 0.15 : 0.22))))} would likely mean losing muscle rather than fat.
              </div>
            )}
          </div>
        )}
      </div>

      {/* SECTION 3: LABS */}
      <div style={crd}>
        <h2 style={sH}>3. Your Numbers Over Time</h2>
        <p style={{ fontSize: "13px", color: "#888", margin: "0 0 4px" }}>Enter your most recent values and — if you have them — a prior reading. One number is a snapshot. Two show direction. Direction matters more.</p>

        <button onClick={() => setPanelInfo(!panelInfo)} style={{ background: "none", border: "none", color: "#0a7c72", fontSize: "13px", fontWeight: 600, cursor: "pointer", padding: "6px 0", marginBottom: "8px" }}>{panelInfo ? "▾ Hide" : "▸ What's"} included in standard bloodwork?</button>
        {panelInfo && (
          <div style={{ padding: "12px", background: "#f0faf8", borderRadius: "8px", marginBottom: "12px", fontSize: "13px", color: "#555", lineHeight: 1.7 }}>
            <strong>Comprehensive Metabolic Panel (CMP):</strong> Glucose, ALT, AST, eGFR, electrolytes, kidney function. Usually part of an annual visit.
            <br /><strong>Lipid Panel:</strong> Total cholesterol, LDL, HDL, triglycerides. Often ordered alongside CMP.
            <br /><strong>Must be specifically requested:</strong> A1c (blood sugar average over ~3 months) and Vitamin D are not standard — you may need to ask your provider to add them.
            <br /><strong>Tip:</strong> Many plans cover annual bloodwork through preventive care benefits. Call your provider's office before your visit to ask what's covered under your plan.
          </div>
        )}

        <div style={{ marginBottom: "12px" }}>
          <Sel label="Time between readings (if you entered prior values)" value={tf} onChange={setTf} options={[
            { value: "unknown", label: "Not sure / only one reading" },
            { value: "3mo", label: "About 3 months" },
            { value: "6mo", label: "About 6 months" },
            { value: "1yr", label: "About 1 year" },
            { value: "2yr", label: "2+ years" },
          ]} />
        </div>

        <div style={{ fontSize: "11px", color: "#aaa", display: "flex", gap: "10px", padding: "6px 0", borderBottom: "2px solid #eee" }}>
          <div style={{ flex: 2, fontWeight: 600 }}>MARKER</div>
          <div style={{ flex: 1, fontWeight: 600 }}>NOW</div>
          <div style={{ flex: 1, fontWeight: 600 }}>BEFORE</div>
          <div style={{ flex: 2, fontWeight: 600 }}>WHERE YOU ARE</div>
        </div>

        {Object.keys(LABS).map(k => {
          const lb = LABS[k];
          const cv = labs[k] ? parseFloat(labs[k]) : null;
          const pv = prior[k] ? parseFloat(prior[k]) : null;
          const st = cv ? labStatus(k, cv) : null;
          const tr = cv && pv ? labTrend(k, cv, pv) : null;
          return (
            <div key={k} style={{ padding: "10px 0", borderBottom: "1px solid #f0f0f0" }}>
              <div style={{ display: "flex", gap: "10px", alignItems: "center", flexWrap: "wrap" }}>
                <div style={{ flex: 2, minWidth: "120px" }}>
                  <div style={{ fontSize: "14px", fontWeight: 500 }}>{lb.label}</div>
                  <div style={{ fontSize: "10px", color: "#bbb" }}>{lb.panel}</div>
                </div>
                <div style={{ flex: 1, minWidth: "80px" }}>
                  <input type="number" step="any" value={labs[k] || ""} onChange={e => setL({ ...labs, [k]: e.target.value })} placeholder="Now" style={{ ...iS, padding: "7px 10px", fontSize: "14px" }} />
                </div>
                <div style={{ flex: 1, minWidth: "80px" }}>
                  <input type="number" step="any" value={prior[k] || ""} onChange={e => setP({ ...prior, [k]: e.target.value })} placeholder="Before" style={{ ...iS, padding: "7px 10px", fontSize: "14px" }} />
                </div>
                <div style={{ flex: 2, minWidth: "130px", display: "flex", gap: "5px", alignItems: "center", flexWrap: "wrap" }}>
                  {st && <Badge label={st.label} color={st.c} />}
                  {tr && <span style={{ fontSize: "12px", color: tr.c, fontWeight: 600 }}>{tr.arrow} {tr.label}</span>}
                </div>
              </div>
              {cv && <RangeBar value={cv} segs={lb.segs} lo={lb.lo} hi={lb.hi} />}
            </div>
          );
        })}

        {tgH && (
          <div style={{ marginTop: "14px", padding: "12px", background: tgH > 3 ? "#fef0e7" : tgH > 2 ? "#fef9e7" : "#eafaf1", borderRadius: "8px", border: `1px solid ${(tgH > 3 ? "#e67e22" : tgH > 2 ? "#f39c12" : "#27ae60")}40` }}>
            <div style={{ fontSize: "14px", fontWeight: 600 }}>
              TG/HDL Ratio: {tgH.toFixed(1)}{" "}
              <Badge label={tgH > 3 ? "Worth discussing with your provider" : tgH > 2 ? "Worth monitoring" : "Looking good"} color={tgH > 3 ? "#e67e22" : tgH > 2 ? "#f39c12" : "#27ae60"} />
            </div>
            <div style={{ fontSize: "13px", color: "#555", marginTop: "5px" }}>This ratio is a proxy for insulin resistance — often more informative than any single cholesterol number. Below 2.0 is where most providers like to see it.</div>
          </div>
        )}
      </div>

      {/* SECTION 4: DOCTOR QUESTIONS */}
      {(canF || hasL) && (
        <div style={{ ...crd, borderTop: "3px solid #0a7c72" }} ref={reportRef}>
          <h2 style={{ ...sH, color: "#0a7c72" }}>4. Questions for Your Provider</h2>
          <p style={{ fontSize: "13px", color: "#888", margin: "0 0 14px" }}>Auto-generated from the data you entered — specific, assertive questions designed to shift the conversation from "lose weight" to "let's look at what's actually happening."</p>

          {qs.length === 0 && (
            <div style={{ padding: "20px", background: "#eafaf1", borderRadius: "8px", textAlign: "center", fontSize: "14px", color: "#27ae60" }}>
              {hasL || canF ? "Everything entered is within reference ranges. Keep tracking — consistency reveals the story." : "Enter your measurements and/or lab values above to generate questions."}
            </div>
          )}

          {qs.length > 0 && (
            <>
              {qs.map((q, i) => (
                <div key={i} style={{ padding: "12px 14px", background: "#f8f9fa", borderRadius: "8px", marginBottom: "8px", borderLeft: "3px solid #0a7c72", fontSize: "14px", lineHeight: 1.6, color: "#333" }}>
                  <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: "22px", height: "22px", borderRadius: "50%", background: "#0a7c72", color: "#fff", fontSize: "11px", fontWeight: 700, marginRight: "10px" }}>{i + 1}</span>
                  {q}
                </div>
              ))}

              <div style={{ fontSize: "13px", fontWeight: 600, color: "#555", marginTop: "14px", marginBottom: "8px" }}>Take these with you:</div>
              <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
                {[
                  { l: "📋 Copy to clipboard", a: copy, primary: true },
                  { l: "📧 Email to myself", a: email },
                  { l: "💬 Text to myself", a: text },
                  { l: "📄 Save as PDF", a: () => window.print() },
                ].map((b, i) => (
                  <button key={i} onClick={b.a} style={{ padding: "10px 16px", background: b.primary ? "#0a7c72" : "#fff", color: b.primary ? "#fff" : "#0a7c72", border: "1.5px solid #0a7c72", borderRadius: "8px", fontSize: "13px", fontWeight: 600, cursor: "pointer", flex: "1 1 auto", minWidth: "140px", textAlign: "center" }}>{b.l}</button>
                ))}
              </div>
              <div style={{ fontSize: "11px", color: "#bbb", marginTop: "6px" }}>For "Save as PDF" on your phone: when the print dialog opens, choose "Save as PDF" instead of selecting a printer.</div>
            </>
          )}

          <div style={{ marginTop: "18px", padding: "12px", background: "#f5f5f5", borderRadius: "8px", fontSize: "12px", color: "#999", lineHeight: 1.6 }}>
            <strong>About this report:</strong> Frame classification follows MedlinePlus/Metropolitan Life wrist circumference standards. Body fat estimated via the U.S. Navy method (Hodgdon & Beckett; ±3.5% vs. DEXA). Lab reference ranges follow ADA, AHA, and KDIGO guidelines. This tool provides estimates for discussion with your provider — not a diagnosis. No data is stored or transmitted.
          </div>
        </div>
      )}

      <div style={{ marginTop: "20px", padding: "14px", textAlign: "center", fontSize: "12px", color: "#ccc" }}>
        Frame-Adjusted Health Report · Zero data stored · 100% on your device
      </div>
    </div>
  );
}
