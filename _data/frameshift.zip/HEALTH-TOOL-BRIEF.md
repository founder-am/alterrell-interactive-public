# HEALTH-TOOL-BRIEF.md
# Frame-Adjusted Health Report — Product Brief
**Last updated:** March 29, 2026
**Status:** Free tier prototype built (v2). Paid tier scoped, not yet built.

---

## What This Is

A browser-based health empowerment tool that uses skeletal frame analysis, body composition estimation, and lab trend tracking to generate personalized, assertive questions for a healthcare provider. Built on the same "Data as Dignity" philosophy as Alterrell Interactive — data reveals what's happening in your body, never judges you.

**Core insight:** BMI was designed for populations, not people. This tool gives individuals — especially heavier people with larger frames — the data and language to challenge one-size-fits-all clinical assessments.

**Tagline candidates (not yet locked):**
- "Your body has a story. The charts weren't reading it."
- "Built for the body BMI forgot."
- "The report your doctor doesn't have yet."

---

## Relationship to Alterrell Interactive

Separate product with its own name (TBD). Connected by philosophy and credibility — "Built by Alterrell Interactive" appears in footer. Not hosted on interactive.alterrell.com. Gets its own domain.

The editorial piece "Being Fat" (in Alterrell pipeline, not yet calendared) serves as the story that introduces the tool — same way the sodium piece introduced the sodium calculator. Story is free, story links to tool, tool charges for deep analysis.

**Design system:** Shares DNA with Alterrell Interactive but is not bound to alterrell-interactive.css. Will develop its own visual identity in a dedicated design session. Tonight's prototype uses functional styling only.

---

## Audience

**Primary (launch):** Person A — "The Visitor to Being Fat." Heavier people who have been told by BMI charts they're broken, get generic advice from doctors, and have never seen their health data synthesized in a way that respects their body. They want recognition — "the charts weren't built for me."

**Secondary (follows naturally):** Person B — Healthcare providers (PTs, dietitians, coaches) who suspect their larger-framed clients are poorly served by standard metrics but lack tools to prove it. The sale becomes: "Your clients are already bringing these reports to appointments."

**Not primary:** Person C — Quantified-self enthusiasts. Too niche, too competitive. May benefit from Tier 2 features but are not the design target.

---

## Product Architecture

### Free Tier — Frame Calculator + Snapshot

**What it does:** Single-session tool. Enter measurements, get a report with doctor questions. No account required. No data stored.

**Four sections (built, working prototype exists as `frame-health-report.jsx`):**

1. **Body Frame Assessment** (required inputs)
   - Sex assigned at birth (with note: "about bone structure, not identity")
   - Height, weight, wrist circumference, ankle circumference (optional)
   - Outputs: frame size classification, frame-adjusted healthy weight range, BMI comparison showing how many lbs BMI is off by

2. **Body Composition Estimate** (optional)
   - Waist, neck, hip circumferences
   - Outputs: Navy method body fat (±3.5%), lean mass, waist-to-hip ratio, composition-based goal weight with muscle-loss floor

3. **Your Numbers Over Time** (optional)
   - Current + prior values for 8 markers: A1c, fasting glucose, triglycerides, HDL, LDL, ALT, eGFR, Vitamin D
   - Time horizon dropdown (3mo / 6mo / 1yr / 2yr)
   - Visual range bar (position on gradient, no diagnostic labels)
   - Trend arrows: "Moving in the right direction" / "Stable" / "Moving in a direction to watch"
   - TG/HDL ratio as insulin resistance proxy
   - Expandable: "What's included in standard bloodwork?" (CMP vs. lipid panel vs. must-request items)

4. **Questions for Your Provider** (auto-generated)
   - Specific, assertive questions based on entered data
   - Frame argument, body fat argument, fat distribution argument, flagged lab trends
   - Four delivery methods: Copy to clipboard, Email to self, Text to self, Save as PDF
   - Methodology disclosure at bottom

**Locked design decisions for free tier:**
- Imperial / Metric toggle (top right)
- "Sex assigned at birth" language with explanation
- No "Adam's apple" — neck instruction says "narrowest point below jaw"
- No "normal" — threshold language throughout ("Within range" / "Approaching threshold" / "Above clinical threshold")
- No diagnostic labels in free tier status badges — position on range, not judgment
- Expandable measurement instructions (how to use a tape measure)
- Softer insurance language ("call your provider's office to ask what's covered")
- "Within range" message when all values are good: "Keep tracking — consistency reveals the story"

### Paid Tier — Intelligence Layer

**What it does:** Turns snapshots into longitudinal insight. User pays for the accumulation and analysis, not the data entry.

**Pricing model (locked):** Pay-per-report ($TBD) plus optional subscription for device data imports.

**Features scoped (not yet built):**

1. **Multi-reading trend engine with projections**
   - Unlimited historical entries per marker with date stamps
   - Actual trend lines and velocity of change
   - Projected trajectories: "At this rate, your A1c will cross 5.7% by [date]"
   - Gets smarter with more data: 1 reading = snapshot, 2 = direction, 3+ = trajectory

2. **Cross-metric correlation analysis**
   - Glucose→liver lag detection (the 3-month pattern)
   - Weight velocity vs. lab marker correlation
   - Stress-responsive marker identification
   - "Your ALT tends to spike 8–12 weeks after glucose elevations"

3. **Exercise prescription calibrated to composition**
   - Based on body fat distribution (central vs. peripheral), frame size, composition
   - Three pillars: resistance training (lean mass protection), Zone 2 cardio (visceral fat), HRV-gated intensity
   - GLP-1 specific: muscle-loss risk scoring, protein targets, resistance training emphasis

4. **GLP-1 muscle-loss risk scoring**
   - If user indicates GLP-1 agonist use, flag lean mass protection protocol
   - Up to 35% of GLP-1 weight loss can be lean mass without resistance training
   - Track lean mass estimate over time to detect muscle loss early

5. **Body composition tracking over time**
   - Monthly circumference entries → radar chart showing body shape change
   - Before/after comparison (body outline SVG from existing dashboard code)
   - "Same weight, different body" reframe with metabolic evidence

6. **Professionally formatted provider report** (PDF)
   - Full data summary designed to be handed to a doctor
   - Not just questions but "here's my patient's longitudinal data"
   - Frame analysis, composition trends, lab trajectories, correlations

### Tier 2 — Device Data Import (subscription, later phase)

**Not MVP.** Browser-native drag-and-drop for Fitbit, Apple Health, CPAP exports. Client-side parsing, zero data transmitted. Full dashboard experience from existing Python codebase, ported to JavaScript.

---

## Data Input Method (Paid Tier)

**Locked decision:** Paste-from-screenshot with manual correction.

**Workflow:**
1. User opens patient portal (MyChart, LabCorp, Quest, etc.)
2. Screenshots lab results page
3. Uses phone's built-in text recognition (iOS Live Text / Android Google Lens) to copy text
4. Pastes into tool's text input field
5. Parser extracts recognized lab values and maps to markers
6. User confirms/corrects in a structured form

**Fallbacks:**
- Print-to-PDF from portal, copy-paste from PDF
- Manual entry with guided walkthrough ("Open your patient portal. Go to Lab Results. Find the most recent CMP. You're looking for these 6 numbers...")

**Not building:** Custom OCR, camera capture, direct API integration with health portals.

**Parser requirements (future build session):**
- Recognize common lab result text formats: "Glucose 103 mg/dL", "A1C: 5.7 %", "eGFR >60"
- Handle LabCorp, Quest, and common hospital lab formatting
- Graceful failure — anything not recognized stays empty for manual entry

---

## Measurement Cadence

**No prescribed schedule.** The tool works with whatever data someone brings:
- 1 reading → snapshot + questions
- 2 readings (any timeframe) → direction + what to watch
- 3+ readings → trajectory + projections + correlations

This removes the "I don't go to the doctor enough" barrier. Realistic acknowledgment that many people aren't getting annual physicals.

---

## What the Free Tier Does NOT Do

- No diagnostic labels or clinical judgments — interpretation belongs to providers
- No data storage — everything is session-only, client-side
- No account creation required
- No trend analysis beyond "current vs. prior" with direction arrow
- No exercise prescription
- No GLP-1 specific guidance
- No correlation detection
- No projection/trajectory modeling

These boundaries exist to protect the dignity frame (free tier empowers the conversation, doesn't replace the provider) and to create clear paid tier value.

---

## Open Questions

1. **Product name** — needs a distinct name under the "Built by Alterrell Interactive" umbrella. Candidates TBD. Should evoke empowerment, not clinical anxiety.

2. **Pricing** — pay-per-report amount TBD. Subscription price for device imports TBD. Need to research comparable products.

3. **Data persistence in paid tier** — if there's no account system, how do returning users access their historical data? Options: browser localStorage (fragile), downloadable data file they re-upload, account system (complexity). Needs resolution.

4. **MyChart/portal screenshot compatibility** — need to verify which major patient portals allow screenshots. Some may block. Print-to-PDF fallback covers this but adds friction.

5. **"Being Fat" editorial piece timing** — this is the marketing vehicle. When does it publish relative to tool launch? Should it come first (build audience) or simultaneous (launch together)?

6. **Legal/compliance review** — "not a diagnosis" disclaimer is present, but should we get eyes on the language before charging? Especially the exercise prescription and GLP-1 content in paid tier.

7. **Provider-facing version** — when does Person B (PT/dietitian/coach) get their own interface? After Person A launch proves demand, or designed in parallel?

8. **Domain** — needs its own URL. TBD.

---

## Technical Architecture

**Free tier:** Single React component (or standalone HTML). No server. No database. Client-side only. Currently exists as `frame-health-report.jsx` (React artifact, v2).

**Paid tier:** TBD. Options include:
- Static site with payment gate (Stripe checkout → unlock features client-side)
- Lightweight backend for payment processing only (Vercel/Netlify functions)
- No backend at all — use Stripe Payment Links and deliver via email

**Existing code assets:**
- `health_dashboard.py` — 2,500-line Python script with all parsing, analysis, and visualization logic. Port to JavaScript for browser-native version.
- `health_dashboard.html` — generated reference dashboard showing full target experience.
- `frame-health-report.jsx` — free tier prototype (React, v2, working).
- Sample data files for all 4 sources (MyAir, Fitbit, Apple Health, body measurements).

---

## Build Sequence

### Phase 1 — Free tier polish + ship (next session)
- Design pass on `frame-health-report.jsx` (own visual identity, not Alterrell CSS)
- Export to standalone HTML
- Deploy to temporary URL for testing
- Write copy for landing page

### Phase 2 — Paid tier: Enhanced Report
- Multi-reading trend engine with date stamps
- Cross-metric correlation detection
- Exercise prescription engine
- GLP-1 module
- Body composition tracking (radar chart over time)
- Paste-from-screenshot parser
- Payment integration (Stripe)
- Professionally formatted PDF report generation

### Phase 3 — Paid tier: Device Import (subscription)
- Port Python parsers to JavaScript (Fitbit, Apple Health, CPAP)
- Drag-and-drop file upload with client-side processing
- Full dashboard experience (Plotly.js)
- Stress timeline inference
- "Your Story" narrative generation

### Phase 4 — Provider-facing version
- Bulk client management
- Report sharing/export for care plans
- Provider-specific pricing

---

## Key Principles (from Alterrell Interactive, applied here)

- **"Data as Dignity"** — data reveals what's happening in your body, never judges you
- **Recognition before outrage** — "oh, the charts weren't built for me" comes before "why wasn't anyone telling me this?"
- **Free tier must not render diagnostic judgments** — interpretation belongs to providers
- **The data collection experience IS the product** — telling users exactly what to get and how to get it is as valuable as the analysis
- **CBUXO lens is non-negotiable** — if it only works for analytical people, it's not done
- **Zero data transmitted** — fully client-side, HIPAA exposure = none
- **The generated questions are the product** — every BMI calculator on the internet tells you you're obese and stops. This tool gives you language.

---

## Session Protocol

Every session on this product must:
1. Read this brief (`HEALTH-TOOL-BRIEF.md`) before acting
2. Confirm which phase/feature is being worked on
3. Present copy and structure for AMA review before building
4. When approaching context limit: flag it, update this brief, confirm handoff

---

## File Map

```
health-tool/
├── HEALTH-TOOL-BRIEF.md              This file
├── frame-health-report.jsx            Free tier prototype (React, v2)
├── HANDOFF.md                         Original dashboard handoff doc
├── health_dashboard.py                Python dashboard (reference/port source)
├── health_dashboard.html              Generated dashboard (visual reference)
└── sample_data/
    ├── MyAir_sample.zip
    ├── FitBit_sample.zip
    ├── AppleHealth_sample.zip
    └── bodymeasurements_sample.txt
```
