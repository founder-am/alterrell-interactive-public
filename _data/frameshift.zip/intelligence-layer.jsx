import { useState, useMemo, useCallback } from "react";

// ============================================================
// MATH
// ============================================================
function linReg(pts) {
  if (pts.length < 2) return null;
  const n = pts.length;
  let sx=0,sy=0,sxy=0,sxx=0;
  for (const p of pts){sx+=p.x;sy+=p.y;sxy+=p.x*p.y;sxx+=p.x*p.x;}
  const d=n*sxx-sx*sx; if(Math.abs(d)<1e-10)return null;
  const slope=(n*sxy-sx*sy)/d, intercept=(sy-slope*sx)/n;
  const yM=sy/n; let sT=0,sR=0;
  for(const p of pts){sT+=(p.y-yM)**2;sR+=(p.y-(slope*p.x+intercept))**2;}
  return{slope,intercept,r2:sT>0?1-sR/sT:0};
}

function navyBF(sex, hIn, waistIn, neckIn, hipIn) {
  if (sex === "M") { const d = waistIn - neckIn; if (d <= 0) return null; return 86.01*Math.log10(d*2.54)-70.041*Math.log10(hIn*2.54)+36.76; }
  if (!hipIn) return null; const s = waistIn + hipIn - neckIn; if (s <= 0) return null;
  return 163.205*Math.log10(s*2.54)-97.684*Math.log10(hIn*2.54)-78.387;
}

// ============================================================
// MARKERS
// ============================================================
const MK = {
  a1c:{label:"A1c",unit:"%",th:[{v:5.7},{v:6.5}],dir:"lower"},
  glucose:{label:"Fasting Glucose",unit:"mg/dL",th:[{v:100},{v:126}],dir:"lower"},
  triglycerides:{label:"Triglycerides",unit:"mg/dL",th:[{v:150},{v:200}],dir:"lower"},
  hdl:{label:"HDL",unit:"mg/dL",th:[{v:40},{v:60}],dir:"higher"},
  ldl:{label:"LDL",unit:"mg/dL",th:[{v:100},{v:160}],dir:"lower"},
  alt:{label:"ALT",unit:"IU/L",th:[{v:40},{v:80}],dir:"lower"},
  egfr:{label:"eGFR",unit:"mL/min",th:[{v:60},{v:90}],dir:"higher"},
  vitd:{label:"Vitamin D",unit:"ng/mL",th:[{v:20},{v:30}],dir:"higher"},
};

// ============================================================
// CORRELATIONS
// ============================================================
function findCorrelations(entries) {
  const ins = [];
  const glc=(entries.glucose||[]).sort((a,b)=>a.dt-b.dt);
  const alt=(entries.alt||[]).sort((a,b)=>a.dt-b.dt);
  if(glc.length>=2&&alt.length>=2){
    for(const g of glc){if(g.v>=100){
      const hit=alt.find(a=>a.dt-g.dt>=60*864e5&&a.dt-g.dt<=120*864e5&&a.v>40);
      if(hit){const gD=g.dt.toLocaleDateString("en-US",{month:"short",year:"numeric"}),aD=hit.dt.toLocaleDateString("en-US",{month:"short",year:"numeric"}),lag=Math.round((hit.dt-g.dt)/864e5);
        ins.push({sev:"high",title:"Glucose → Liver Lag Pattern Detected",
          detail:`Glucose elevated (${g.v} mg/dL) in ${gD}. ALT rose to ${hit.v} IU/L ~${lag} days later (${aD}). Metabolic stress appears in blood sugar first; the liver responds 8–12 weeks later.`,
          cite:"Westerbacka et al., Diabetes Care 2004; Marchesini et al., Hepatology 2003",
          q:`My glucose elevations seem to precede ALT spikes by 2–3 months. Can we use glucose as an early warning and intervene before liver enzymes rise?`});}
    }}
  }
  const tg=(entries.triglycerides||[]).sort((a,b)=>a.dt-b.dt);
  const hdl=(entries.hdl||[]).sort((a,b)=>a.dt-b.dt);
  if(tg.length>=2&&hdl.length>=2){
    const rs=[];
    for(const t of tg){const c=hdl.reduce((b,h)=>Math.abs(h.dt-t.dt)<Math.abs(b.dt-t.dt)?h:b);if(Math.abs(c.dt-t.dt)<30*864e5)rs.push({dt:t.dt,r:t.v/c.v});}
    if(rs.length>=2){const f=rs[0],l=rs[rs.length-1];if(f.r>2||l.r>2)ins.push({sev:l.r>3?"high":"moderate",title:"TG/HDL Ratio Trend — Insulin Resistance Proxy",
      detail:`TG/HDL ratio moved from ${f.r.toFixed(1)} to ${l.r.toFixed(1)}. ${l.r<f.r?"Moving in the right direction.":"Worth discussing."} Ratios above 2.0 are associated with insulin resistance.`,
      cite:"McLaughlin et al., Circulation 2005; Gaziano et al., Circulation 1997",
      q:`My TG/HDL ratio moved from ${f.r.toFixed(1)} to ${l.r.toFixed(1)}. Should we investigate insulin resistance with a fasting insulin test?`});}
  }
  const a1c=(entries.a1c||[]).sort((a,b)=>a.dt-b.dt);
  if(a1c.length>=1&&glc.length>=2){
    const la=a1c[a1c.length-1],eAG=la.v*28.7-46.7;
    const rec=glc.filter(g=>Math.abs(g.dt-la.dt)<90*864e5);
    if(rec.length>=1){const avg=rec.reduce((s,g)=>s+g.v,0)/rec.length;if(Math.abs(eAG-avg)>25)ins.push({sev:"moderate",title:"A1c and Fasting Glucose Tell Different Stories",
      detail:`A1c ${la.v}% implies avg glucose ~${Math.round(eAG)} mg/dL. Fasting readings average ${Math.round(avg)} — a ${Math.round(Math.abs(eAG-avg))} point gap. Post-meal spikes may be higher than fasting suggests.`,
      cite:"Nathan et al., Diabetes Care 2008",
      q:`My A1c implies avg glucose ~${Math.round(eAG)}, but fasting averages ${Math.round(avg)}. Should we consider a CGM trial?`});}
  }
  const egfr=(entries.egfr||[]).sort((a,b)=>a.dt-b.dt);
  if(egfr.length>=3){
    const d0=egfr[0].dt;const pts=egfr.map(e=>({x:(e.dt-d0)/864e5,y:e.v}));const reg=linReg(pts);
    if(reg&&reg.slope<0){const ann=reg.slope*365;if(ann<-2){const lv=egfr[egfr.length-1].v;const y60=lv>60?(lv-60)/Math.abs(ann):null;
      ins.push({sev:ann<-4?"high":"moderate",title:"eGFR Decline Rate",
        detail:`eGFR declining ~${ann.toFixed(1)} units/year. Normal is ~1 unit/year after 40.${y60?` At this rate, threshold of 60 in ~${y60.toFixed(1)} years.`:""} Early intervention can slow this.`,
        cite:"KDIGO 2012 Guidelines; Turin et al., CMAJ 2012",
        q:`My eGFR is declining at ${ann.toFixed(1)}/year. What can we do — medication, diet, hydration?`});}}
  }
  return ins;
}

// ============================================================
// MOVEMENT GUIDE
// ============================================================
function moveGuide(frameSize, bf, whr, sex, wLbs, lean, onGLP1, proportions) {
  const g = [];
  const central = whr && ((sex==="M"&&whr>0.95)||(sex==="F"&&whr>0.85));
  const heavy = frameSize==="Large"||frameSize==="Very Large";
  const hw = wLbs && wLbs > 250;

  g.push({p:1,c:"#c0392b",icon:"🏋️",title:"Resistance Training — Protect Your Structure",freq:"3× / week, 40–55 min",
    why:onGLP1?"Without resistance training, research shows 20–35% of GLP-1 weight loss can come from lean mass. Resistance training is the primary countermeasure.":"Resistance training preserves the muscle that drives metabolism. For larger frames, compound movements are effective because your skeleton can handle significant load.",
    cite:onGLP1?"Wilding et al., NEJM 2021; Ida et al., J Cachexia Sarcopenia Muscle 2023":"Westcott, Curr Sports Med Rep 2012; Peterson et al., Med Sci Sports Exerc 2011",
    pts:[hw?"Start with machines for joint safety — progress to free weights as stability builds":"Mix machines and free weights — prioritize form over load","Compound: leg press, chest press, cable rows, lat pulldown","3 sets × 8–12 reps, progressive overload each session","Rest 90–120 sec between sets"]});

  if(central||(bf&&((sex==="M"&&bf>25)||(sex==="F"&&bf>32)))){
    g.push({p:2,c:"#2980b9",icon:"🚴",title:central?"Zone 2 Cardio — Targets Central Fat Distribution":"Zone 2 Cardio — Steady-State Fat Metabolism",freq:"3–4× / week, 30–45 min",
      why:central?"Zone 2 intensity (60–70% max HR) is particularly effective at reducing visceral fat. Research shows it outperforms HIIT for this specific purpose, without cortisol elevation.":"Zone 2 keeps you in a fat-metabolizing intensity and builds aerobic capacity without excessive joint stress.",
      cite:"Keating et al., J Obes 2017; Irving et al., Med Sci Sports Exerc 2008",
      pts:["Target: you should be able to hold a conversation",...(hw?["Best at current weight: bike, rowing, swimming, elliptical — lower joint impact"]:["Walking, cycling, swimming, elliptical"]),"Cardio after lifting on combined days, not before","Stay in the zone — harder is not better for fat metabolism"]});
  }

  // Proportion-based
  if(proportions.waist&&proportions.hip&&proportions.thigh){
    const wh=proportions.waist/proportions.hip;
    const tw=proportions.thigh/proportions.waist;
    let shape,desc,best,less;
    if(wh>0.92&&tw<0.65){
      shape="Central-Dominant"; desc="Your midsection carries more mass relative to your limbs. This proportion responds well to activities that don't compress the spine or fold at the waist.";
      best=["Swimming — buoyancy reduces joint load, full-body engagement","Rowing machine — seated, engages core and legs without spinal compression","Recumbent cycling — back-supported, leg-focused","Incline walking — cardiovascular without impact","Pilates (modified) — core stability work with controlled range of motion"];
      less=["Running at higher weights — joint impact concentrated through heavier center of gravity","Traditional crunches — compressive and often uncomfortable with a larger midsection","Deep forward folds in yoga — may feel restricted; modify with blocks or wider stance"];
    } else {
      shape="Balanced / Lower-Body Strength"; desc="Your proportions are relatively balanced or your legs carry significant strength. This is structurally advantageous for many movements.";
      best=["Cycling — your legs are your engine","Leg press and squat variations — your structure supports load well","Elliptical — uses your natural lower-body power","Stair climbing — leverages existing strength","Yoga — your proportions allow full range of motion in most poses"];
      less=["Exclusively upper-body isolation — build on your lower-body base instead","Marathon training above 250 lbs — cumulative joint stress over distance"];
    }
    g.push({p:2.5,c:"#8e44ad",icon:"🧭",title:`What Your Shape Suggests — ${shape}`,freq:"Based on your proportions",
      why:desc,cite:"Heymsfield et al., Am J Clin Nutr 2007; ACSM Guidelines, 11th ed.",
      pts:[...best.map(s=>"✓ "+s),"","Activities that may need modification:",...less.map(s=>"△ "+s)]});
  }

  if(onGLP1){
    g.push({p:1.5,c:"#e67e22",icon:"💊",title:"GLP-1 Considerations — Lean Mass Protection",freq:"Integrated with training",
      why:"GLP-1 agonists accelerate weight loss, but without intervention a meaningful portion comes from muscle. Research is clear: resistance training and adequate protein are the primary countermeasures.",
      cite:"Wilding et al., NEJM 2021; Ida et al., 2023; Mechanick et al., Endocr Pract 2020",
      pts:[lean?`Estimated lean mass: ~${Math.round(lean)} lbs. Track monthly — if waist shrinks but arms/thighs shrink at the same rate, you may be losing muscle.`:"Track circumferences monthly. If waist and limbs shrink at the same rate, you may be losing muscle along with fat.","Protein: 0.7–1.0g per lb of lean mass daily","Prioritize protein first in every meal if appetite is suppressed","Consider creatine monohydrate 3–5g daily (well-researched for maintenance)"]});
  }

  g.push({p:3,c:"#27ae60",icon:"📡",title:"Recovery — Let Your Body Set the Pace",freq:"Daily awareness",
    why:"If you track resting heart rate or HRV, those numbers tell you whether to push or rest. Training hard on a stressed day compounds stress rather than building fitness.",
    cite:"Plews et al., Int J Sports Physiol Perform 2013; Buchheit, Sports Med 2014",
    pts:["High resting HR / low HRV → active recovery: walk, mobility, stretching","Normal readings → moderate session","Strong readings → push intensity","Poor sleep (< 6 hrs) → reduce effort automatically"]});

  return g.sort((a,b)=>a.p-b.p);
}

// ============================================================
// RADAR CHART (SVG)
// ============================================================
function ProportionRadar({ measurements, sex }) {
  // measurements = {neck, chest, waist, hip, thigh, calf, bicep}
  const labels = ["Neck","Chest","Waist","Hips","Thigh","Calf","Bicep"];
  const keys = ["neck","chest","waist","hip","thigh","calf","bicep"];
  const vals = keys.map(k => measurements[k] ? parseFloat(measurements[k]) : 0);
  const hasData = vals.some(v => v > 0);
  if (!hasData) return null;

  // Normalize to 0–1 range based on typical ranges
  const ranges = sex === "M"
    ? { neck:[14,21], chest:[36,54], waist:[28,54], hip:[34,58], thigh:[20,34], calf:[13,22], bicep:[11,20] }
    : { neck:[12,18], chest:[30,48], waist:[24,46], hip:[32,54], thigh:[18,30], calf:[12,19], bicep:[9,16] };

  const norm = keys.map((k,i) => {
    const [lo,hi] = ranges[k];
    return vals[i] > 0 ? Math.max(0, Math.min(1, (vals[i]-lo)/(hi-lo))) : 0;
  });

  const cx = 160, cy = 155, maxR = 120;
  const n = labels.length;
  const angleStep = (2 * Math.PI) / n;
  const startAngle = -Math.PI / 2;

  const toXY = (i, r) => ({
    x: cx + r * Math.cos(startAngle + i * angleStep),
    y: cy + r * Math.sin(startAngle + i * angleStep),
  });

  // Grid rings
  const rings = [0.25, 0.5, 0.75, 1.0];

  // Data polygon
  const dataPoints = norm.map((v, i) => toXY(i, v * maxR));
  const dataPath = dataPoints.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(" ") + " Z";

  return (
    <div style={{ textAlign: "center" }}>
      <svg width="320" height="320" viewBox="0 0 320 310" style={{ maxWidth: "100%" }}>
        {/* Grid */}
        {rings.map((r, ri) => {
          const pts = Array.from({ length: n }, (_, i) => toXY(i, r * maxR));
          const d = pts.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(" ") + " Z";
          return <path key={ri} d={d} fill="none" stroke="#e0e0e0" strokeWidth="1" />;
        })}
        {/* Axis lines */}
        {labels.map((_, i) => {
          const p = toXY(i, maxR);
          return <line key={i} x1={cx} y1={cy} x2={p.x} y2={p.y} stroke="#e8e8e8" strokeWidth="1" />;
        })}
        {/* Data fill */}
        <path d={dataPath} fill="rgba(10,124,114,0.15)" stroke="#0a7c72" strokeWidth="2.5" />
        {/* Data points */}
        {dataPoints.map((p, i) => vals[i] > 0 && (
          <circle key={i} cx={p.x} cy={p.y} r="5" fill="#0a7c72" stroke="#fff" strokeWidth="2" />
        ))}
        {/* Labels */}
        {labels.map((l, i) => {
          const p = toXY(i, maxR + 18);
          const anchor = p.x < cx - 10 ? "end" : p.x > cx + 10 ? "start" : "middle";
          return <g key={i}>
            <text x={p.x} y={p.y} textAnchor={anchor} fontSize="11" fontWeight="600" fill="#555" dominantBaseline="central">{l}</text>
            {vals[i] > 0 && <text x={p.x} y={p.y + 13} textAnchor={anchor} fontSize="10" fill="#999" dominantBaseline="central">{vals[i]}"</text>}
          </g>;
        })}
      </svg>
      <div style={{ fontSize: "11px", color: "#aaa", marginTop: "4px" }}>Your proportions mapped against typical ranges. Shape reveals which movements fit your body.</div>
    </div>
  );
}

// ============================================================
// SPARKLINE
// ============================================================
function Spark({points,thresholds,w:width=280,h:height=80}){
  if(points.length<2)return null;
  const p={t:8,r:12,b:18,l:34};const W=width-p.l-p.r,H=height-p.t-p.b;
  const vs=points.map(q=>q.y),all=[...vs,...thresholds.map(t=>t.v)];
  const mn=Math.min(...all)*0.92,mx=Math.max(...all)*1.08,mX=points[0].x,xX=points[points.length-1].x,rX=xX-mX||1,rY=mx-mn||1;
  const sx=x=>p.l+((x-mX)/rX)*W,sy=y=>p.t+H-((y-mn)/rY)*H;
  const d=points.map((q,i)=>`${i===0?"M":"L"} ${sx(q.x).toFixed(1)} ${sy(q.y).toFixed(1)}`).join(" ");
  const reg=linReg(points);let td="";
  if(reg){const x0=mX,x1=xX+(xX-mX)*0.3;td=`M ${sx(x0).toFixed(1)} ${sy(reg.slope*x0+reg.intercept).toFixed(1)} L ${sx(x1).toFixed(1)} ${sy(reg.slope*x1+reg.intercept).toFixed(1)}`;}
  return(<svg width={width} height={height} style={{display:"block"}}>
    {thresholds.map((t,i)=>{const y=sy(t.v);if(y<p.t||y>p.t+H)return null;return<g key={i}><line x1={p.l} y1={y} x2={p.l+W} y2={y} stroke="#e74c3c" strokeWidth="1" strokeDasharray="4,3" opacity="0.4"/><text x={p.l+W+2} y={y+3} fontSize="9" fill="#e74c3c" opacity="0.7">{t.v}</text></g>;})}
    {td&&<path d={td} stroke="#2980b9" strokeWidth="1.5" strokeDasharray="4,4" fill="none" opacity="0.5"/>}
    <path d={d} stroke="#1a2535" strokeWidth="2" fill="none"/>
    {points.map((q,i)=><circle key={i} cx={sx(q.x)} cy={sy(q.y)} r="4" fill="#1a2535" stroke="#fff" strokeWidth="1.5"/>)}
    <text x={p.l-4} y={p.t+4} fontSize="9" fill="#aaa" textAnchor="end">{Math.round(mx)}</text>
    <text x={p.l-4} y={p.t+H} fontSize="9" fill="#aaa" textAnchor="end">{Math.round(mn)}</text>
  </svg>);
}

// ============================================================
// STYLES & HELPERS
// ============================================================
const iS={width:"100%",padding:"8px 10px",border:"1px solid #ddd",borderRadius:"6px",fontSize:"14px",fontFamily:"inherit",background:"#fff",boxSizing:"border-box"};
const crd={background:"#fff",border:"1px solid #e8e8e8",borderRadius:"10px",padding:"20px",marginBottom:"16px"};
function Badge({label,color}){return<span style={{display:"inline-block",padding:"3px 9px",borderRadius:"12px",fontSize:"11px",fontWeight:600,background:color+"18",color,border:`1px solid ${color}40`,whiteSpace:"nowrap"}}>{label}</span>;}

// ============================================================
// MAIN
// ============================================================
export default function IntelV2() {
  const [entries, setEntries] = useState({});
  const [panelDate, setPanelDate] = useState("");
  const [panelVals, setPanelVals] = useState({});

  const [sex, setSex] = useState("M");
  const [frameSize, setFrameSize] = useState("Large");
  const [weight, setWeight] = useState("");
  const [dims, setDims] = useState({ neck:"",chest:"",waist:"",hip:"",thigh:"",calf:"",bicep:"" });
  const [onGLP1, setOnGLP1] = useState(false);

  const hIn = 69; // placeholder
  const wLbs = weight ? parseFloat(weight) : null;
  const waistIn = dims.waist ? parseFloat(dims.waist) : null;
  const neckIn = dims.neck ? parseFloat(dims.neck) : null;
  const hipIn = dims.hip ? parseFloat(dims.hip) : null;
  const thighIn = dims.thigh ? parseFloat(dims.thigh) : null;

  const bf = useMemo(() => navyBF(sex, hIn, waistIn, neckIn, hipIn), [sex, waistIn, neckIn, hipIn]);
  const lean = bf && wLbs ? wLbs * (1 - bf / 100) : null;
  const whr = waistIn && hipIn ? waistIn / hipIn : null;

  // Add a full panel of labs at once
  const addPanel = useCallback(() => {
    if (!panelDate) return;
    const dt = new Date(panelDate);
    const up = { ...entries };
    for (const [k, v] of Object.entries(panelVals)) {
      if (!v) continue;
      if (!up[k]) up[k] = [];
      // Avoid duplicate dates
      up[k] = [...up[k].filter(e => e.dt.toDateString() !== dt.toDateString()), { dt, v: parseFloat(v) }].sort((a, b) => a.dt - b.dt);
    }
    setEntries(up);
    setPanelVals({});
    setPanelDate("");
  }, [panelDate, panelVals, entries]);

  const removeEntry = (mk, idx) => {
    setEntries(p => { const a = [...(p[mk]||[])]; a.splice(idx, 1); return { ...p, [mk]: a }; });
  };

  const totalEntries = Object.values(entries).reduce((s, a) => s + a.length, 0);

  // Trends
  const trends = useMemo(() => {
    const r = {};
    for (const [k, arr] of Object.entries(entries)) {
      if (arr.length < 2) continue;
      const d0 = arr[0].dt;
      const pts = arr.map(e => ({ x: (e.dt - d0) / 864e5, y: e.v }));
      const reg = linReg(pts);
      const vel = reg ? reg.slope * 30 : null;
      const m = MK[k];
      const improving = m && vel !== null && ((m.dir === "lower" && vel < 0) || (m.dir === "higher" && vel > 0));
      // Projections
      const projs = [];
      if (m && reg && arr.length >= 2) {
        const last = pts[pts.length - 1];
        for (const t of m.th) {
          const pastIt = m.dir === "lower" ? last.y <= t.v : last.y >= t.v;
          if (pastIt) continue;
          const movingRight = m.dir === "lower" ? reg.slope < 0 : reg.slope > 0;
          if (!movingRight) { projs.push({ warn: true, msg: `Not currently trending toward ${t.v} ${m.unit}. Trend is flat or moving away.` }); continue; }
          const daysTo = (t.v - (reg.slope * last.x + reg.intercept)) / reg.slope;
          const daysFromNow = daysTo - last.x;
          if (daysFromNow <= 0) continue;
          const months = Math.round(daysFromNow / 30);
          const dt = new Date(Date.now() + daysFromNow * 864e5);
          projs.push({ msg: `Projected to reach ${t.v} ${m.unit} by ~${dt.toLocaleDateString("en-US", { month: "short", year: "numeric" })} (~${months} months at current rate).`, warn: false });
        }
      }
      r[k] = { reg, vel, pts, projs, improving, count: arr.length };
    }
    return r;
  }, [entries]);

  const correlations = useMemo(() => findCorrelations(entries), [entries]);

  const movement = useMemo(() => {
    if (!frameSize && !bf) return null;
    return moveGuide(frameSize, bf, whr, sex, wLbs, lean, onGLP1, { waist: waistIn, hip: hipIn, thigh: thighIn });
  }, [frameSize, bf, whr, sex, wLbs, lean, onGLP1, waistIn, hipIn, thighIn]);

  return (
    <div style={{ maxWidth: "760px", margin: "0 auto", padding: "20px 16px", fontFamily: '-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif', color: "#1a2535", background: "#fafafa", minHeight: "100vh" }}>

      {/* HEADER */}
      <div style={{ marginBottom: "24px", padding: "16px 20px", background: "linear-gradient(135deg,#0a7c72,#1a5276)", borderRadius: "12px", color: "#fff" }}>
        <div style={{ fontSize: "11px", fontWeight: 600, textTransform: "uppercase", letterSpacing: "1px", opacity: 0.7, marginBottom: "4px" }}>Enhanced Report — Intelligence Layer</div>
        <h1 style={{ fontSize: "24px", fontWeight: 700, margin: "0 0 6px" }}>What Your Numbers Are Actually Telling You</h1>
        <p style={{ fontSize: "14px", opacity: 0.85, margin: 0, lineHeight: 1.5 }}>Add lab panels by date. Enter your measurements. The more data, the smarter the analysis — trend projections, cross-metric patterns, and movement insights built for your body.</p>
      </div>

      {/* BODY CONTEXT + RADAR */}
      <div style={crd}>
        <h2 style={{ fontSize: "22px", fontWeight: 700, margin: "0 0 4px" }}>Your Body</h2>
        <p style={{ fontSize: "12px", color: "#aaa", margin: "0 0 12px" }}>These measurements generate your proportion map and inform movement recommendations. In the full product, frame size and body fat carry over from the free assessment.</p>

        <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", marginBottom: "10px" }}>
          <div style={{ flex: 1, minWidth: "100px" }}>
            <label style={{ fontSize: "12px", color: "#888" }}>Sex at birth</label>
            <select value={sex} onChange={e => setSex(e.target.value)} style={iS}><option value="M">Male</option><option value="F">Female</option></select>
          </div>
          <div style={{ flex: 1, minWidth: "100px" }}>
            <label style={{ fontSize: "12px", color: "#888" }}>Frame (auto in full product)</label>
            <select value={frameSize} onChange={e => setFrameSize(e.target.value)} style={iS}>
              <option value="">—</option><option value="Small">Small</option><option value="Medium">Medium</option><option value="Large">Large</option><option value="Very Large">Very Large</option>
            </select>
          </div>
          <div style={{ flex: 1, minWidth: "80px" }}>
            <label style={{ fontSize: "12px", color: "#888" }}>Weight (lbs)</label>
            <input type="number" value={weight} onChange={e => setWeight(e.target.value)} placeholder="282" style={iS} />
          </div>
        </div>

        <div style={{ fontSize: "13px", fontWeight: 600, color: "#555", margin: "8px 0 6px" }}>Circumferences (inches)</div>
        <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
          {[["neck","Neck"],["chest","Chest"],["waist","Waist"],["hip","Hips"],["thigh","Thigh"],["calf","Calf"],["bicep","Bicep"]].map(([k,l]) => (
            <div key={k} style={{ flex: 1, minWidth: "70px" }}>
              <label style={{ fontSize: "11px", color: "#999" }}>{l}</label>
              <input type="number" step="0.25" value={dims[k]} onChange={e => setDims({ ...dims, [k]: e.target.value })} placeholder="—" style={{ ...iS, padding: "6px 8px", fontSize: "13px" }} />
            </div>
          ))}
        </div>

        <label style={{ display: "flex", alignItems: "center", gap: "8px", marginTop: "10px", fontSize: "14px", cursor: "pointer" }}>
          <input type="checkbox" checked={onGLP1} onChange={e => setOnGLP1(e.target.checked)} />
          I'm on a GLP-1 medication (Ozempic, Wegovy, Mounjaro, Zepbound, or similar)
        </label>

        {/* Calculated metrics */}
        {(bf || whr) && (
          <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", marginTop: "12px" }}>
            {bf && <div style={{ padding: "8px 12px", background: "#f0faf8", borderRadius: "8px", fontSize: "13px" }}><strong>Est. body fat:</strong> {bf.toFixed(1)}% (±3.5%)</div>}
            {lean && <div style={{ padding: "8px 12px", background: "#f0faf8", borderRadius: "8px", fontSize: "13px" }}><strong>Est. lean mass:</strong> {Math.round(lean)} lbs</div>}
            {whr && <div style={{ padding: "8px 12px", background: "#f0faf8", borderRadius: "8px", fontSize: "13px" }}><strong>WHR:</strong> {whr.toFixed(2)}</div>}
          </div>
        )}

        {/* RADAR CHART */}
        <ProportionRadar measurements={dims} sex={sex} />
      </div>

      {/* BATCH LAB ENTRY */}
      <div style={crd}>
        <h2 style={{ fontSize: "22px", fontWeight: 700, margin: "0 0 4px" }}>Add a Lab Panel</h2>
        <p style={{ fontSize: "12px", color: "#aaa", margin: "0 0 10px" }}>Pick a test date, then fill in all the markers from that panel at once. Come back and add older panels too — even years-old results help detect trends.</p>

        <div style={{ marginBottom: "10px" }}>
          <label style={{ fontSize: "12px", color: "#888" }}>Test date</label>
          <input type="date" value={panelDate} onChange={e => setPanelDate(e.target.value)} style={{ ...iS, maxWidth: "200px" }} />
        </div>

        <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
          {Object.entries(MK).map(([k, m]) => (
            <div key={k} style={{ flex: 1, minWidth: "80px" }}>
              <label style={{ fontSize: "11px", color: "#999" }}>{m.label} <span style={{ color: "#ccc" }}>({m.unit})</span></label>
              <input type="number" step="any" value={panelVals[k] || ""} onChange={e => setPanelVals({ ...panelVals, [k]: e.target.value })} placeholder="—" style={{ ...iS, padding: "6px 8px", fontSize: "13px" }} />
            </div>
          ))}
        </div>

        <button onClick={addPanel} disabled={!panelDate || !Object.values(panelVals).some(v => v)} style={{ marginTop: "10px", padding: "10px 20px", background: !panelDate ? "#ccc" : "#0a7c72", color: "#fff", border: "none", borderRadius: "6px", fontSize: "14px", fontWeight: 600, cursor: panelDate ? "pointer" : "default" }}>
          + Add Panel
        </button>

        {/* Summary of entered data */}
        {totalEntries > 0 && (
          <div style={{ marginTop: "14px" }}>
            {Object.entries(entries).map(([k, arr]) => {
              if (!arr.length) return null;
              return (
                <div key={k} style={{ display: "flex", alignItems: "center", gap: "6px", flexWrap: "wrap", padding: "6px 0", borderBottom: "1px solid #f0f0f0" }}>
                  <span style={{ fontSize: "13px", fontWeight: 600, minWidth: "100px" }}>{MK[k].label}</span>
                  {arr.map((e, i) => (
                    <span key={i} style={{ display: "inline-flex", alignItems: "center", gap: "3px", padding: "3px 7px", background: "#f4f4f4", borderRadius: "5px", fontSize: "12px" }}>
                      <span style={{ color: "#888" }}>{e.dt.toLocaleDateString("en-US", { month: "short", year: "2-digit" })}</span>
                      <strong>{e.v}</strong>
                      <button onClick={() => removeEntry(k, i)} style={{ background: "none", border: "none", color: "#ccc", cursor: "pointer", fontSize: "13px", padding: "0 2px" }}>×</button>
                    </span>
                  ))}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* TRENDS */}
      {Object.keys(trends).length > 0 && (
        <div style={crd}>
          <h2 style={{ fontSize: "22px", fontWeight: 700, margin: "0 0 4px" }}>Trend Analysis</h2>
          <p style={{ fontSize: "12px", color: "#aaa", margin: "0 0 14px" }}>Direction and velocity for each marker. Blue dotted line shows projected trajectory.</p>
          {Object.entries(trends).map(([k, t]) => {
            const m = MK[k]; const arr = entries[k];
            return (
              <div key={k} style={{ marginBottom: "14px", padding: "14px", background: "#f8f9fa", borderRadius: "8px", borderLeft: `3px solid ${t.improving ? "#27ae60" : "#e67e22"}` }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "6px" }}>
                  <div><span style={{ fontSize: "16px", fontWeight: 600 }}>{m.label}</span><span style={{ fontSize: "14px", color: "#888", marginLeft: "8px" }}>{arr[0].v} → {arr[arr.length-1].v} {m.unit}</span></div>
                  <div style={{ display: "flex", gap: "6px", alignItems: "center" }}>
                    <Badge label={t.improving ? "Right direction" : "Worth watching"} color={t.improving ? "#27ae60" : "#e67e22"} />
                    <span style={{ fontSize: "12px", color: "#888" }}>{t.vel > 0 ? "+" : ""}{t.vel.toFixed(2)}/mo</span>
                  </div>
                </div>
                <Spark points={t.pts} thresholds={m.th} />
                {t.projs.map((p, i) => <div key={i} style={{ marginTop: "4px", fontSize: "13px", color: p.warn ? "#e67e22" : "#555" }}>{p.warn ? "⚠ " : "📈 "}{p.msg}</div>)}
                {t.reg && <div style={{ fontSize: "11px", color: "#ccc", marginTop: "3px" }}>Confidence: R² = {t.reg.r2.toFixed(2)} · {t.reg.r2 > 0.7 ? "strong trend" : t.reg.r2 > 0.4 ? "moderate" : "weak — more data points will improve"}</div>}
              </div>
            );
          })}
        </div>
      )}

      {/* CORRELATIONS */}
      {correlations.length > 0 && (
        <div style={crd}>
          <h2 style={{ fontSize: "22px", fontWeight: 700, margin: "0 0 4px" }}>Pattern Detection</h2>
          <p style={{ fontSize: "12px", color: "#aaa", margin: "0 0 12px" }}>Cross-metric patterns that only emerge when you look across markers and time.</p>
          {correlations.map((c, i) => (
            <div key={i} style={{ marginBottom: "12px", padding: "14px", borderRadius: "8px", borderLeft: `3px solid ${c.sev === "high" ? "#c0392b" : "#e67e22"}`, background: c.sev === "high" ? "#fef5f5" : "#fef9f0" }}>
              <div style={{ fontSize: "15px", fontWeight: 600, color: c.sev === "high" ? "#c0392b" : "#e67e22", marginBottom: "5px" }}>{c.title}</div>
              <div style={{ fontSize: "13px", color: "#444", lineHeight: 1.6, marginBottom: "6px" }}>{c.detail}</div>
              <div style={{ fontSize: "11px", color: "#aaa", marginBottom: "6px", fontStyle: "italic" }}>Research: {c.cite}</div>
              <div style={{ fontSize: "13px", padding: "8px 10px", background: "#fff", borderRadius: "6px", borderLeft: "2px solid #0a7c72" }}>
                <strong style={{ color: "#0a7c72", fontSize: "11px" }}>QUESTION FOR YOUR PROVIDER:</strong><br />{c.q}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* MOVEMENT GUIDE */}
      {movement && (
        <div style={crd}>
          <h2 style={{ fontSize: "22px", fontWeight: 700, margin: "0 0 4px" }}>What Your Body Is Built For</h2>
          <p style={{ fontSize: "12px", color: "#aaa", margin: "0 0 14px" }}>Movement suggestions based on your frame, proportions, composition, and medication status. Every recommendation is grounded in peer-reviewed research.</p>
          {movement.map((rx, i) => (
            <div key={i} style={{ marginBottom: "14px", padding: "14px", background: "#f8f9fa", borderRadius: "8px", borderTop: `3px solid ${rx.c}` }}>
              <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "8px" }}>
                <span style={{ fontSize: "20px" }}>{rx.icon}</span>
                <div><div style={{ fontSize: "16px", fontWeight: 600, color: rx.c }}>{rx.title}</div><div style={{ fontSize: "12px", color: "#888" }}>{rx.freq}</div></div>
              </div>
              <div style={{ fontSize: "13px", color: "#555", lineHeight: 1.6, marginBottom: "8px" }}>{rx.why}</div>
              <div style={{ fontSize: "11px", color: "#aaa", marginBottom: "8px", fontStyle: "italic" }}>Research: {rx.cite}</div>
              {rx.pts.map((p, j) => p === "" ? <div key={j} style={{ height: "6px" }} /> : (
                <div key={j} style={{ fontSize: "13px", color: "#444", padding: "4px 8px", background: p.startsWith("✓") ? "#eafaf1" : p.startsWith("△") ? "#fef9f0" : "#fff", borderRadius: "4px", marginBottom: "3px", borderLeft: `2px solid ${p.startsWith("✓") ? "#27ae60" : p.startsWith("△") ? "#f39c12" : rx.c}30` }}>{p}</div>
              ))}
            </div>
          ))}
        </div>
      )}

      {/* EMPTY STATE */}
      {totalEntries === 0 && !movement && (
        <div style={{ padding: "40px 20px", textAlign: "center", color: "#aaa" }}>
          <div style={{ fontSize: "32px", marginBottom: "10px" }}>📊</div>
          <div style={{ fontSize: "16px", fontWeight: 600, color: "#888" }}>Add your measurements and lab panels to see the intelligence layer</div>
          <div style={{ fontSize: "13px", marginTop: "6px" }}>Enter body measurements for the proportion map and movement guide. Add lab panels with dates for trend analysis and pattern detection.</div>
        </div>
      )}

      <div style={{ marginTop: "20px", padding: "12px", textAlign: "center", fontSize: "12px", color: "#ccc" }}>
        Intelligence Layer Prototype · Zero data stored · All research cited inline
      </div>
    </div>
  );
}
